//
//  CapturaViewController.swift
//  Runner
//
//  Created by c93514a on 07/07/23.
//

import UIKit
import Flutter
import brscan_sdk_selfie_ios

class SelfieCaptureViewController: UIViewController {
    var flutterResult: FlutterResult
    var arguments: [String: Any]
    
    
    init(flutterResult: @escaping FlutterResult, arguments: [String: Any]) {
        self.flutterResult = flutterResult
        self.arguments = arguments
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    func start() {
        
    let chave = arguments["chave"] as! String
    let wizard = arguments["wizard"] as! Bool
    let segurancaExtraSslPinning = arguments["segurancaExtraSslPinning"] as! Bool
    let segurancaExtraRootCheck = arguments["segurancaExtraRootCheck"] as! Bool
    let tipoRetorno = arguments["tipoRetorno"] as! String
    let performance = arguments["performance"] as! Bool
    let customizacaoTexto = arguments["configuracaoTexto"] as! [String: String]
    let retornarErros = arguments["retornarErros"] as! Bool
    let verificarLuminosidade = arguments["verificarLuminosidade"] as! Bool
    let verificarOlhos = arguments["verificarOlhos"] as! Bool
    let mudarCamera = arguments["mudarCamera"] as! Bool
    let segurancaExtraEmulatorCheck = arguments["segurancaExtraEmulatorCheck"] as! Bool
    let telaConfirmacaoDeSaida = arguments["telaConfirmacaoDeSaida"] as! Bool
    let customizacaoTextoSelfie = mapToTextConfiguration(textConfigurationMap: customizacaoTexto)
        let captura = CapturaSViewController(
            chave: chave,
            wizard: wizard,
            mudarCamera: mudarCamera,
            segurancaExtraRootCheck: segurancaExtraRootCheck,
            segurancaExtraSslPinning: segurancaExtraSslPinning,
            verificarLuminosidade: verificarLuminosidade,
            performance: performance,
            verificarOlhos: verificarOlhos,
            tipoRetorno: tipoRetorno,
            customizacaoTexto: customizacaoTextoSelfie,
            retornarErros: retornarErros,
            segurancaExtraEmulatorCheck: segurancaExtraEmulatorCheck,
            telaConfirmacaoDeSaida: telaConfirmacaoDeSaida
        )
        view.backgroundColor = .white
        captura.delegate = self
        addChild(captura)
        view.addSubview(captura.view)
        captura.didMove(toParent: self)
        captura.view.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        captura.view.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        captura.view.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        captura.view.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        start()
        
    }
    
    func mapToTextConfiguration(textConfigurationMap: [String: String]?) -> ConfiguracaoTextoSelfie {
        let textConfiguration = ConfiguracaoTextoSelfie(brscan_selfie_erro_selfie_captura: textConfigurationMap?["brscan_selfie_erro_selfie_captura"] ?? "",
                                                        brscan_selfie_erro_ao_conectar_no_servidor: textConfigurationMap?["brscan_selfie_erro_ao_conectar_no_servidor"] ?? "",
                                                        brscan_selfie_erro_ao_validar_chave: textConfigurationMap?["brscan_selfie_erro_ao_validar_chave"] ?? "",
                                                        brscan_selfie_erro_baixa_luminosidade: textConfigurationMap?["brscan_selfie_erro_baixa_luminosidade"] ?? "",
                                                        brscan_selfie_erro_device_rooted: textConfigurationMap?["brscan_selfie_erro_device_rooted"] ?? "",
                                                        brscan_selfie_erro_usuario_cancelou_acao: textConfigurationMap?["brscan_selfie_erro_usuario_cancelou_acao"] ?? "",
                                                        brscan_selfie_erro_liberar_camera: textConfigurationMap?["brscan_selfie_erro_liberar_camera"] ?? "",
                                                        brscan_selfie_erro_servidor: textConfigurationMap?["brscan_selfie_erro_servidor"] ?? "",
                                                        brscan_selfie_erro_processo: textConfigurationMap?["brscan_selfie_erro_processo"] ?? "",
                                                        brscan_selfie_erro_token_expired: textConfigurationMap?["brscan_selfie_erro_token_expired"] ?? "",
                                                        brscan_selfie_erro_acesso_negado_title: textConfigurationMap?["brscan_selfie_erro_acesso_negado_title"] ?? "",
                                                        brscan_selfie_erro_acesso_negado_subtitle: textConfigurationMap?["brscan_selfie_erro_acesso_negado_subtitle"] ?? "",
                                                        brscan_selfie_erro_acesso_negado_botao_de_acao: textConfigurationMap?["brscan_selfie_erro_acesso_negado_botao_de_acao"] ?? "",
                                                        brscan_selfie_erro_captura_title: textConfigurationMap?["brscan_selfie_erro_captura_title"] ?? "",
                                                        brscan_selfie_erro_captura_subtitle: textConfigurationMap?["brscan_selfie_erro_captura_subtitle"] ?? "",
                                                        brscan_selfie_erro_captura_botao_tentar_novamente: textConfigurationMap?["brscan_selfie_erro_captura_botao_tentar_novamente"] ?? "",
                                                        brscan_selfie_erro_captura_botao_sair_do_processo: textConfigurationMap?["brscan_selfie_erro_captura_botao_sair_do_processo"] ?? "",
                                                        brscan_selfie_posicione_o_aparelho_na_vertical: textConfigurationMap?["brscan_selfie_posicione_o_aparelho_na_vertical"] ?? "",
                                                        brscan_selfie_centralize_o_rosto: textConfigurationMap?["brscan_selfie_centralize_o_rosto"] ?? "",
                                                        brscan_selfie_aguarde_um_instante: textConfigurationMap?["brscan_selfie_aguarde_um_instante"] ?? "",
                                                        brscan_selfie_aguardando_o_rosto: textConfigurationMap?["brscan_selfie_aguardando_o_rosto"] ?? "",
                                                        brscan_selfie_fique_sozinho: textConfigurationMap?["brscan_selfie_fique_sozinho"] ?? "",
                                                        brscan_selfie_alinhe_o_rosto: textConfigurationMap?["brscan_selfie_alinhe_o_rosto"] ?? "",
                                                        brscan_selfie_aproxime_o_aparelho: textConfigurationMap?["brscan_selfie_aproxime_o_aparelho"] ?? "",
                                                        brscan_selfie_afaste_o_aparelho: textConfigurationMap?["brscan_selfie_afaste_o_aparelho"] ?? "",
                                                        brscan_selfie_mantenha_os_olhos_abertos: textConfigurationMap?["brscan_selfie_mantenha_os_olhos_abertos"] ?? "",
                                                        brscan_selfie_camera_frontal: textConfigurationMap?["brscan_selfie_camera_frontal"] ?? "",
                                                        brscan_selfie_camera_traseira: textConfigurationMap?["brscan_selfie_camera_traseira"] ?? "",
                                                        brscan_selfie_loading: textConfigurationMap?["brscan_selfie_loading"] ?? "",
                                                        brscan_selfie_erro_device_emulated: textConfigurationMap?["brscan_selfie_erro_device_emulated"] ?? "",
                                                        brscan_selfie_erro_accelerometer: textConfigurationMap?["brscan_selfie_erro_accelerometer"] ?? "",
                                                        brscan_selfie_sucesso_foto_valida: textConfigurationMap?["brscan_selfie_sucesso_foto_valida"] ?? ""
        )
        
        return textConfiguration
    }
}

extension SelfieCaptureViewController: CapturaSViewControllerDelegate {
    func sucessoDelegate(_ selfie: [String : String]) {
        let response : NSMutableDictionary! = [:]
        response["imagem"] = selfie["imagem"]
        response["id"] = selfie["id"]
        flutterResult(response)
        navigationController?.popToRootViewController(animated: false)
    }
    
    func erroDelegate(_ erro: [String : Any]) {
        let response : NSMutableDictionary! = [:]
        response["codigo"] = erro["codigo"]  as! Int
        response["descricao"] = erro["descricao"]  as! String
        response["id"] = erro["id"]  as! String
        flutterResult(response)
        navigationController?.popToRootViewController(animated: false)
    }
    
    func callbackProcessamentoLiveness(_ notificationLiveness: [String: Any]) {
        let response : NSMutableDictionary! = [:]
        response["status"] = notificationLiveness["status"]
        response["code"] = notificationLiveness["code"]
        response["description"] = notificationLiveness["description"]
        response["id"] = notificationLiveness["id"]
        response["captureHour"] = notificationLiveness["captureHour"]
        response["time"] = notificationLiveness["time"]
        response["image"] = notificationLiveness["image"]
        flutterResult(response)
    }
}



