package br.com.serasa.demo.demobiometria;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import br.com.brscan.sdk.android.selfielib.activities.SelfieActivity;
import br.com.brscan.sdk.android.selfielib.models.ConfiguracaoTexto;
import br.com.brscan.sdk.android.selfielib.models.Erro;
import br.com.brscan.sdk.android.selfielib.models.Selfie;

public class MainActivity extends AppCompatActivity {

    private ActivityResultLauncher<Intent> someActivityResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        someActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        Selfie selfie;
                        if (data != null) {
                            selfie = (Selfie) data.getSerializableExtra("selfie");
                            if (selfie != null) {
                                Log.d("MainActivity", "selfie: " + selfie.toString());
                                Toast.makeText(this,"Sucesso",Toast.LENGTH_LONG).show();
                            } else {
                                Erro erro = (Erro) data.getSerializableExtra("erro");
                                if(erro!=null){
                                    Log.d("MainActivity", " erro " + erro.toString());
                                    Toast.makeText(this,erro.getDescricao(), Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    }
                });

        Button btnCaptureSelfie = findViewById(R.id.btn_action);
        btnCaptureSelfie.setOnClickListener(view -> startCapture());


    }


    private void startCapture() {
        Intent intent = new Intent(this, SelfieActivity.class);

        intent.putExtra("chave", "");// INSERIR A CHAVE AQUI
        intent.putExtra("mudarCamera", false);
        intent.putExtra("wizard", false);
        intent.putExtra("verificarLuminosidade", false);
        intent.putExtra("verificarOlhos", false);
        intent.putExtra("performance", false);
        intent.putExtra("retornarErros", false);
        intent.putExtra("segurancaExtra", true);
        intent.putExtra("segurancaExtraRootCheck", false);
        intent.putExtra("segurancaExtraEmulatorCheck", false);
        intent.putExtra("tipoRetorno","base64");

        intent.putExtra("acessibilidade", false);

        final ConfiguracaoTexto configuracaoTexto = new ConfiguracaoTexto();
        configuracaoTexto.brscan_selfie_loading = "Aguarde um instante ...";
        /*
            ...
         */
        intent.putExtra("configuracaoTexto", configuracaoTexto);


        someActivityResultLauncher.launch(intent);
    }
}