//
//  brscan_sdk_selfie_ios.h
//  brscan-sdk-selfie-ios
//
//  Created by C93514A on 03/11/21.
//

#import <Foundation/Foundation.h>

//! Project version number for brscan_sdk_selfie_ios.
FOUNDATION_EXPORT double brscan_sdk_selfie_iosVersionNumber;

//! Project version string for brscan_sdk_selfie_ios.
FOUNDATION_EXPORT const unsigned char brscan_sdk_selfie_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <brscan_sdk_selfie_ios/PublicHeader.h>


