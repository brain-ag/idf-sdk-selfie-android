import 'package:flutter/services.dart';

const channelName = "serasa.idf/selfie";
const eventStartCapture = "startCapture";
const eventSelfieCallbackListener = "callbackProcessamentoLiveness";

const keyChave = "chave";
const keyMudarCamera = "mudarCamera";
const keySegurancaExtraSslPinning = "segurancaExtraSslPinning";
const keySegurancaExtraRootCheck = "segurancaExtraRootCheck";
const keySegurancaExtraEmulatorCheck = "segurancaExtraEmulatorCheck";
const keyWizard = "wizard";
const keyVerificarLuminosidade = "verificarLuminosidade";
const keyRetornarErros = "retornarErros";
const keyTelaConfirmacaoDeSaida = "telaConfirmacaoDeSaida";
const keyVerificarOlhos = "verificarOlhos";
const keyPerformance = "performance";
const keyTipoRetorno = "tipoRetorno";
const keyConfiguracaoTexto = "configuracaoTexto";

const keyResultId = "id";
const keyResultImage = "imagem";
const keyResultErrorCode = "codigo";
const keyResultErrorDescription = "descricao";

const keySuccess = "sucesso";
const keyFailure = "falha";
const keyImage = "image";
const keyStatus = "status";
const keyTime = "time";
const keyCode = "code";
const keyCaptureHour = "captureHour";
const keyDescription = "description";

const platform = MethodChannel(channelName);

void startCapture(
    {required Map params,
    required Function(Map selfie) onSuccess,
    required Function(Map error) onError,
    required Function(Map callbackListener) onCallbackListener}) async {
  try {
    startSelfieCallbackListener(onCallbackListener: onCallbackListener);
    Map result =
        await platform.invokeMethod<Map>(eventStartCapture, params) as Map;

    if (result.containsKey(keyResultImage)) {
      onSuccess(result);
    } else {
      onError(result);
    }
  } on PlatformException catch (e) {
    Map genericError =  <String, Object>{};
    genericError[keyResultErrorCode] = -1;    
    genericError[keyResultId] = "";
    genericError[keyResultErrorDescription] =  e.message;
    onError(genericError);
  }
}

void startSelfieCallbackListener (
    {required Function(Map callbackListener) onCallbackListener}) async {
  try {
    Map result =
        await platform.invokeMethod<Map>(eventSelfieCallbackListener) as Map;
    onCallbackListener(result);
  } on PlatformException catch (_) {
  } finally {
    startSelfieCallbackListener(onCallbackListener: onCallbackListener);
  }
}