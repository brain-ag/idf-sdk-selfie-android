#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>
#import <brscan_sdk_selfie_ios/brscan_sdk_selfie_ios.h>
#import <React/RCTLog.h>
#import "AppDelegate.h"

#import <React/RCTModalHostView.h>
#import <React/RCTModalHostViewController.h>

NS_ASSUME_NONNULL_BEGIN

@interface SerasaIdfCaptureSelfie : NSObject <RCTBridgeModule, CapturaSViewControllerDelegate>

@end

NS_ASSUME_NONNULL_END
