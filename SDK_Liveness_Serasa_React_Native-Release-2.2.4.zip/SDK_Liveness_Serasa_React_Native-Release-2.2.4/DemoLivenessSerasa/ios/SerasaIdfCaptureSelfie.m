#import "SerasaIdfCaptureSelfie.h"
#include <math.h>

@implementation SerasaIdfCaptureSelfie

RCTResponseSenderBlock success2D;
RCTResponseSenderBlock error2D;
RCTResponseSenderBlock livenessSerasaCallBack;

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(callbackProcessamentoLivenessSerasa:(RCTResponseSenderBlock)livenessCallback) {
  @try {
    livenessSerasaCallBack = livenessCallback;
    
  } @catch (NSError *exception) {
    livenessCallback(@[exception]);
  }
}

RCT_EXPORT_METHOD(
                  captureSelfie:(NSString *)chave
                  mudarCamera:(BOOL *)mudarCamera
                  wizard:(BOOL *)wizard
                  segurancaExtraSslPinning:(BOOL *)segurancaExtraSslPinning
                  segurancaExtraRootCheck:(BOOL *)segurancaExtraRootCheck
                  verificarLuminosidade:(BOOL *)verificarLuminosidade
                  verificarOlhos:(BOOL *)verificarOlhos
                  performance:(BOOL *)performance
                  resolucao:(NSString *)resolucao
                  tipoRetorno:(NSString *)tipoRetorno
                  customizacaoTexto:(NSDictionary *)customizacaoTexto
                  retornarErros:(BOOL *)retornarErros
                  acessibilidade:(BOOL *)acessibilidade
                  segurancaExtraEmulatorCheck:(BOOL *)segurancaExtraEmulatorCheck
                  telaConfirmacaoDeSaida:(BOOL *)telaConfirmacaoDeSaida
                  successCallback: (RCTResponseSenderBlock)successCallback
                  errorCallback: (RCTResponseSenderBlock)errorCallback)
{
  
  @try {
    
    success2D = successCallback;
    error2D = errorCallback;
    
    dispatch_async(dispatch_get_main_queue(), ^{
      ConfiguracaoTextoSelfie *configTexto = [[ConfiguracaoTextoSelfie alloc]
                                              initWithBrscan_selfie_erro_selfie_captura: [customizacaoTexto objectForKey: @"brscan_selfie_erro_selfie_captura"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_selfie_captura"] : @""
                                                brscan_selfie_erro_ao_conectar_no_servidor: [customizacaoTexto objectForKey: @"brscan_selfie_erro_ao_conectar_no_servidor"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_ao_conectar_no_servidor"] : @""
                                                brscan_selfie_erro_ao_validar_chave: [customizacaoTexto objectForKey: @"brscan_selfie_erro_ao_validar_chave"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_ao_validar_chave"] : @""
                                                brscan_selfie_erro_baixa_luminosidade: [customizacaoTexto objectForKey: @"brscan_selfie_erro_baixa_luminosidade"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_baixa_luminosidade"] : @""
                                                brscan_selfie_erro_device_rooted: [customizacaoTexto objectForKey: @"brscan_selfie_erro_device_rooted"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_device_rooted"] : @""
                                                brscan_selfie_erro_usuario_cancelou_acao: [customizacaoTexto objectForKey: @"brscan_selfie_erro_usuario_cancelou_acao"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_usuario_cancelou_acao"] : @""
                                                brscan_selfie_erro_liberar_camera: [customizacaoTexto objectForKey: @"brscan_selfie_erro_liberar_camera"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_liberar_camera"] : @""
                                                brscan_selfie_erro_servidor: [customizacaoTexto objectForKey: @"brscan_selfie_erro_servidor"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_servidor"] : @""
                                                brscan_selfie_erro_processo: [customizacaoTexto objectForKey: @"brscan_selfie_erro_processo"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_processo"] : @""
                                                brscan_selfie_erro_token_expired: [customizacaoTexto objectForKey: @"brscan_selfie_erro_token_expired"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_token_expired"] : @""
                                                brscan_selfie_erro_acesso_negado_title: [customizacaoTexto objectForKey: @"brscan_selfie_erro_acesso_negado_title"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_acesso_negado_title"] : @""
                                                brscan_selfie_erro_acesso_negado_subtitle: [customizacaoTexto objectForKey: @"brscan_selfie_erro_acesso_negado_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_acesso_negado_subtitle"] : @""
                                                brscan_selfie_erro_acesso_negado_botao_de_acao: [customizacaoTexto objectForKey: @"brscan_selfie_erro_acesso_negado_botao_de_acao"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_acesso_negado_botao_de_acao"] : @""
                                                brscan_selfie_erro_captura_title: [customizacaoTexto objectForKey: @"brscan_selfie_erro_captura_title"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_captura_title"] : @""
                                                brscan_selfie_erro_captura_subtitle: [customizacaoTexto objectForKey: @"brscan_selfie_erro_captura_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_captura_subtitle"] : @""
                                                brscan_selfie_erro_captura_botao_tentar_novamente: [customizacaoTexto objectForKey: @"brscan_selfie_erro_captura_botao_tentar_novamente"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_captura_botao_tentar_novamente"] : @""
                                                brscan_selfie_erro_captura_botao_sair_do_processo: [customizacaoTexto objectForKey: @"brscan_selfie_erro_captura_botao_sair_do_processo"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_captura_botao_sair_do_processo"] : @""
                                                brscan_selfie_posicione_o_aparelho_na_vertical: [customizacaoTexto objectForKey: @"brscan_selfie_posicione_o_aparelho_na_vertical"] ? [customizacaoTexto objectForKey:@"brscan_selfie_posicione_o_aparelho_na_vertical"] : @""
                                                brscan_selfie_centralize_o_rosto: [customizacaoTexto objectForKey: @"brscan_selfie_centralize_o_rosto"] ? [customizacaoTexto objectForKey:@"brscan_selfie_centralize_o_rosto"] : @""
                                                brscan_selfie_aguarde_um_instante: [customizacaoTexto objectForKey: @"brscan_selfie_aguarde_um_instante"] ? [customizacaoTexto objectForKey:@"brscan_selfie_aguarde_um_instante"] : @""
                                                brscan_selfie_aguardando_o_rosto: [customizacaoTexto objectForKey: @"brscan_selfie_aguardando_o_rosto"] ? [customizacaoTexto objectForKey:@"brscan_selfie_aguardando_o_rosto"] : @""
                                                brscan_selfie_fique_sozinho: [customizacaoTexto objectForKey: @"brscan_selfie_fique_sozinho"] ? [customizacaoTexto objectForKey:@"brscan_selfie_fique_sozinho"] : @""
                                                brscan_selfie_alinhe_o_rosto: [customizacaoTexto objectForKey: @"brscan_selfie_alinhe_o_rosto"] ? [customizacaoTexto objectForKey:@"brscan_selfie_alinhe_o_rosto"] : @""
                                                brscan_selfie_aproxime_o_aparelho: [customizacaoTexto objectForKey: @"brscan_selfie_aproxime_o_aparelho"] ? [customizacaoTexto objectForKey:@"brscan_selfie_aproxime_o_aparelho"] : @""
                                                brscan_selfie_afaste_o_aparelho: [customizacaoTexto objectForKey: @"brscan_selfie_afaste_o_aparelho"] ? [customizacaoTexto objectForKey:@"brscan_selfie_afaste_o_aparelho"] : @""
                                                brscan_selfie_mantenha_os_olhos_abertos: [customizacaoTexto objectForKey: @"brscan_selfie_mantenha_os_olhos_abertos"] ? [customizacaoTexto objectForKey:@"brscan_selfie_mantenha_os_olhos_abertos"] : @""
                                                brscan_selfie_camera_frontal: [customizacaoTexto objectForKey: @"brscan_selfie_camera_frontal"] ? [customizacaoTexto objectForKey:@"brscan_selfie_camera_frontal"] : @""
                                                brscan_selfie_camera_traseira: [customizacaoTexto objectForKey: @"brscan_selfie_camera_traseira"] ? [customizacaoTexto objectForKey:@"brscan_selfie_camera_traseira"] : @""
                                                brscan_selfie_loading: [customizacaoTexto objectForKey: @"brscan_selfie_loading"] ? [customizacaoTexto objectForKey:@"brscan_selfie_loading"] : @""
                                                brscan_selfie_erro_device_emulated: [customizacaoTexto objectForKey: @"brscan_selfie_erro_device_emulated"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_device_emulated"] : @""
                                                brscan_selfie_erro_accelerometer: [customizacaoTexto objectForKey: @"brscan_selfie_erro_accelerometer"] ? [customizacaoTexto objectForKey:@"brscan_selfie_erro_accelerometer"] : @""
                                                brscan_selfie_sucesso_foto_valida: [customizacaoTexto objectForKey: @"brscan_selfie_sucesso_foto_valida"] ? [customizacaoTexto objectForKey:@"brscan_selfie_sucesso_foto_valida"] : @""
      ];
      
      CapturaSViewController *controller = [[CapturaSViewController alloc] initWithChave:chave wizard:wizard mudarCamera:mudarCamera segurancaExtra:true segurancaExtraRootCheck:segurancaExtraRootCheck segurancaExtraSslPinning:segurancaExtraSslPinning verificarLuminosidade:verificarLuminosidade resolucao:resolucao performance:performance verificarOlhos:verificarOlhos tipoRetorno:tipoRetorno customizacaoTexto: configTexto retornarErros:retornarErros tempoDelayMensagem:0 acessibilidade:acessibilidade segurancaExtraEmulatorCheck:segurancaExtraEmulatorCheck telaConfirmacaoDeSaida:telaConfirmacaoDeSaida];
      
      controller.delegate = self;
      
      UINavigationController* appNavigator = [[UINavigationController alloc] initWithRootViewController:controller];
      [appNavigator setModalPresentationStyle:UIModalPresentationFullScreen];
      appNavigator.navigationBarHidden = true;
      AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
      [delegate.window.rootViewController presentViewController:appNavigator animated:NO completion:nil];
      
    });
  } @catch (NSError *exception) {
    errorCallback(@[exception]);
  }
}

- (void)closeCapture {
  AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
  [delegate.window.rootViewController dismissViewControllerAnimated:NO completion:nil];
}

- (void)erroDelegate:(NSDictionary<NSString *,id> *)erro {
  NSDictionary *dicErroSelfie = @{
    @"codigo": [erro objectForKey:@"codigo"],
    @"descricao": [erro objectForKey:@"descricao"],
    @"id": [erro objectForKey:@"id"],
  };

  error2D(@[dicErroSelfie]);
  [self closeCapture];
}

- (void)sucessoDelegate:(NSDictionary<NSString *,NSString *> * _Nonnull)selfie {
  NSDictionary *dicSelfie = @{
    @"imagem": [selfie objectForKey:@"imagem"],
    @"id": [selfie objectForKey:@"id"],
  };
  success2D(@[dicSelfie]);
  [self closeCapture];
}

- (void)callbackProcessamentoLiveness:(NSDictionary<NSString *,id> * _Nonnull)notificationLiveness { 
  NSDictionary *dicErroDoc = @{
    @"status": [notificationLiveness objectForKey:@"status"],
    @"code": [notificationLiveness objectForKey:@"code"],
    @"description": [notificationLiveness objectForKey:@"description"],
    @"id": [notificationLiveness objectForKey:@"id"],
    @"captureHour": [notificationLiveness objectForKey:@"captureHour"],
    @"time": [notificationLiveness objectForKey:@"time"],
    @"image": [notificationLiveness objectForKey:@"image"],
  };
  livenessSerasaCallBack(@[dicErroDoc]);
}

@end





