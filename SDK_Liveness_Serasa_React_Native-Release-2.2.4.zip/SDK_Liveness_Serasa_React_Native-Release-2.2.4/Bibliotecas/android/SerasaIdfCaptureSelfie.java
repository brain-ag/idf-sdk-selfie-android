package br.com.serasa.demo.liveness;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.ActivityEventListener;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;

import java.io.Serializable;
import java.lang.reflect.Field;

import br.com.brscan.sdk.android.selfielib.activities.SelfieActivity;
import br.com.brscan.sdk.android.selfielib.models.ConfiguracaoTexto;
import br.com.brscan.sdk.android.selfielib.models.Erro;
import br.com.brscan.sdk.android.selfielib.models.Selfie;
import br.com.brscan.sdk.android.selfielib.utils.ProcessamentoLivenessCallbackConstants;


public class SerasaIdfCaptureSelfie extends ReactContextBaseJavaModule implements ActivityEventListener {

    private static final String TAG = "SerasaIdfCaptureSelfie";
    private static final int REQUEST_CODE_SELFIE = 1004;
    private SelfieConfig selfieConfig;
    private Callback sucessoCallback;
    private Callback erroCallback;
    private Callback callbackListener;
    private Selfie selfie;
    private Erro erro;

    public SerasaIdfCaptureSelfie(ReactApplicationContext context) {
        super(context);
        context.addActivityEventListener(this);
    }

    @NonNull
    @Override
    public String getName() {
        return "SerasaIdfCaptureSelfie";
    }


    @ReactMethod
    public void captureSelfie(String chave, boolean mudarCamera, boolean wizard, boolean segurancaExtraSslPinning, boolean segurancaExtraRootCheck,
                              boolean verificarLuminosidade, boolean verificarOlhos, boolean performance, String resolucao,
                              String tipoRetorno, ReadableMap configuracaoTextoReadable, boolean retornarErros, boolean acessibilidade,
                              boolean segurancaExtraEmulatorCheck, boolean telaConfirmacaoDeSaida, Callback sucessoCallback, Callback erroCallback) {
        this.selfieConfig = new SelfieConfig(chave, mudarCamera, wizard, segurancaExtraSslPinning, segurancaExtraRootCheck, verificarLuminosidade, verificarOlhos, performance, resolucao, tipoRetorno, configuracaoTextoReadable, retornarErros, acessibilidade, segurancaExtraEmulatorCheck, telaConfirmacaoDeSaida);
        this.sucessoCallback = sucessoCallback;
        this.erroCallback = erroCallback;
        this.selfie = null;
        this.erro = null;
        iniciaCaptura();
    }


    @ReactMethod
    public void callbackProcessamentoLivenessSerasa(Callback callbackListener) {
        this.callbackListener = callbackListener;
    }


    private void iniciaCaptura() {
        Intent intent = new Intent(getCurrentActivity(), SelfieActivity.class);
        intent.putExtra("chave", this.selfieConfig.getChave());
        intent.putExtra("mudarCamera", this.selfieConfig.isMudarCamera());
        intent.putExtra("wizard", this.selfieConfig.isWizard());
        intent.putExtra("segurancaExtraSslPinning", this.selfieConfig.isSegurancaExtraSslPinning());
        intent.putExtra("segurancaExtraRootCheck", this.selfieConfig.isSegurancaExtraRootCheck());
        intent.putExtra("verificarLuminosidade", this.selfieConfig.isVerificarLuminosidade());
        intent.putExtra("verificarOlhos", this.selfieConfig.isVerificarOlhos());
        intent.putExtra("performance", this.selfieConfig.isPerformance());
        intent.putExtra("resolucao", this.selfieConfig.getResolucao());
        intent.putExtra("tipoRetorno", this.selfieConfig.getTipoRetorno());
        intent.putExtra("configuracaoTextoReadable", this.selfieConfig.getConfiguracaoTexto());
        intent.putExtra("retornarErros", this.selfieConfig.isRetornarErros());
        intent.putExtra("acessibilidade", this.selfieConfig.isAcessibilidade());
        intent.putExtra("segurancaExtraEmulatorCheck", this.selfieConfig.isSegurancaExtraEmulatorCheck());
        intent.putExtra("telaConfirmacaoDeSaida", this.selfieConfig.isTelaConfirmacaoDeSaida());

        SelfieActivity.callbackProcessamentoLiveness = result -> {


            try {


                String status = result.has("status") ? result.getString("status") : "";
                int code = result.has("code") ? result.getInt("code") : 0;
                String id = result.has("id") ? result.getString("id") : "";
                String description = result.has("description") ? result.getString("description") : "";
                int time = result.has("time") ? result.getInt("time") : 0;
                String captureHour = result.has("captureHour") ? result.getString("captureHour") : "";
                String image = result.has("image") ? result.getString("image") : "";


                WritableMap errorMap = Arguments.createMap();
                errorMap.putString("status", status);
                errorMap.putInt("code", code);
                errorMap.putString("id", id);
                errorMap.putString("description", description);
                errorMap.putInt("time", time);
                errorMap.putString("captureHour", captureHour);
                errorMap.putString("image", image);

                if (callbackListener != null) {
                    callbackListener.invoke(errorMap);
                }

            } catch (Exception e) {
                Log.d(TAG, "onCallback: " + e.getMessage());
            }
        };

        if (getCurrentActivity() != null)
            getCurrentActivity().startActivityForResult(intent, REQUEST_CODE_SELFIE);
    }

    @Override
    public void onActivityResult(Activity activity, int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CODE_SELFIE) {
                Selfie selfie = (Selfie) data.getSerializableExtra("selfie");

                if (selfie != null) {
                    WritableMap selfieMap = Arguments.createMap();
                    selfieMap.putString("id", selfie.getId());
                    selfieMap.putString("imagem", selfie.getImagem());
                    sucessoCallback.invoke(selfieMap);
                } else {
                    Erro erro = (Erro) data.getSerializableExtra("erro");

                    if (erro != null) {
                        WritableMap erroMap = Arguments.createMap();
                        erroMap.putInt("codigo", erro.getCodigo());
                        erroMap.putString("descricao", erro.getDescricao());
                        erroMap.putString("id", erro.getId());
                        erroCallback.invoke(erroMap);
                    }
                }
            }
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
    }


    public class SelfieConfig implements Serializable {

        private final String chave;
        private final boolean wizard;
        private final boolean mudarCamera;
        private ConfiguracaoTexto configuracaoTexto;
        private final boolean segurancaExtraRootCheck;
        private final boolean segurancaExtraSslPinning;
        private final boolean verificarLuminosidade;
        private final String resolucao;
        private final String tipoRetorno;
        private final boolean performance;
        private final boolean verificarOlhos;
        private final boolean retornarErros;
        private final boolean acessibilidade;
        private final boolean segurancaExtraEmulatorCheck;
        private final boolean telaConfirmacaoDeSaida;

        public SelfieConfig(String chave, boolean mudarCamera, boolean wizard, boolean segurancaExtraSslPinning, boolean segurancaExtraRootCheck, boolean verificarLuminosidade, boolean verificarOlhos, boolean performance, String resolucao, String tipoRetorno, ReadableMap configuracaoTextoWritable, boolean retornarErros, boolean acessibilidade, boolean segurancaExtraEmulatorCheck, boolean telaConfirmacaoDeSaida) {
            this.chave = chave;
            this.mudarCamera = mudarCamera;
            this.wizard = wizard;
            this.segurancaExtraRootCheck = segurancaExtraRootCheck;
            this.segurancaExtraSslPinning = segurancaExtraSslPinning;
            this.verificarLuminosidade = verificarLuminosidade;
            this.verificarOlhos = verificarOlhos;
            this.performance = performance;
            this.resolucao = resolucao;
            this.tipoRetorno = tipoRetorno;
            this.retornarErros = retornarErros;
            this.acessibilidade = acessibilidade;
            this.segurancaExtraEmulatorCheck = segurancaExtraEmulatorCheck;
            this.telaConfirmacaoDeSaida = telaConfirmacaoDeSaida;
            readableMapSelfieConfiguracaoTexto(configuracaoTextoWritable);
        }

        public String getChave() {
            return chave;
        }

        public boolean isWizard() {
            return wizard;
        }

        public boolean isMudarCamera() {
            return mudarCamera;
        }

        public ConfiguracaoTexto getConfiguracaoTexto() {
            return configuracaoTexto;
        }

        public boolean isSegurancaExtraRootCheck() {
            return segurancaExtraRootCheck;
        }

        public boolean isSegurancaExtraSslPinning() {
            return segurancaExtraSslPinning;
        }

        public boolean isSegurancaExtraEmulatorCheck() {
            return segurancaExtraEmulatorCheck;
        }

        public boolean isVerificarLuminosidade() {
            return verificarLuminosidade;
        }

        public String getResolucao() {
            return resolucao;
        }

        public String getTipoRetorno() {
            return tipoRetorno;
        }

        public boolean isPerformance() {
            return performance;
        }

        public boolean isVerificarOlhos() {
            return verificarOlhos;
        }

        public boolean isRetornarErros() {
            return retornarErros;
        }

        public boolean isAcessibilidade() {
            return acessibilidade;
        }

        public boolean isTelaConfirmacaoDeSaida() {
            return telaConfirmacaoDeSaida;
        }

        private void readableMapSelfieConfiguracaoTexto(ReadableMap configuracaoWritable) {
            configuracaoTexto = new ConfiguracaoTexto();
            if (configuracaoWritable == null) return;

            Field[] fs = configuracaoTexto.getClass().getFields();
            for (Field fild : fs) {
                try {
                    String value = configuracaoWritable.getString(fild.getName());
                    fild.set(configuracaoTexto, value);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
