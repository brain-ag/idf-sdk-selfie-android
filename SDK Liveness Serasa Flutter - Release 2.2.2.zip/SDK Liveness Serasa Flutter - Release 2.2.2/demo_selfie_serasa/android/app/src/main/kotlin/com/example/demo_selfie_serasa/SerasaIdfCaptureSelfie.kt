package com.example.demo_selfie_serasa

import android.app.Activity
import android.content.Context
import android.content.Intent
import br.com.brscan.sdk.android.selfielib.activities.SelfieActivity
import br.com.brscan.sdk.android.selfielib.handles.CallbackProcessamentoLiveness
import br.com.brscan.sdk.android.selfielib.models.ConfiguracaoTexto
import br.com.brscan.sdk.android.selfielib.models.Erro
import br.com.brscan.sdk.android.selfielib.models.Selfie
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.FlutterPlugin.FlutterPluginBinding
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.PluginRegistry.ActivityResultListener
import java.lang.reflect.Field


class SerasaIdfCaptureSelfie : FlutterPlugin, MethodCallHandler, ActivityAware,
        ActivityResultListener {

    private var channel: MethodChannel? = null
    private var result: MethodChannel.Result? = null
    private var activity: Activity? = null
    private var activityBinding: ActivityPluginBinding? = null
    private var context: Context? = null
    private var pendingCallbackResult: MethodChannel.Result? = null
    private var pendingResult: MethodChannel.Result? = null
    private val listSDKDocumentMethod = listOf(
            DART_TO_SDK_EVENT_START_CAPTURE,
            DART_TO_SDK_EVENT_DOCUMENT_CALLBACK_LISTENER
    )


    @Synchronized
    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        if (listSDKDocumentMethod.contains(call.method)) {
            if (call.method == DART_TO_SDK_EVENT_DOCUMENT_CALLBACK_LISTENER) {
                pendingCallbackResult = result;
            } else {
                pendingResult = result
                start(call)
            }


            return
        } else {
            result.notImplemented()
        }
    }

    @Synchronized
    private fun start(call: MethodCall) {
        val argumentsMap = call.arguments as HashMap<*, *>

        when (call.method) {
            DART_TO_SDK_EVENT_START_CAPTURE -> {
                val key = argumentsMap[FIELD_PARAM_KEY] as String?
                val wizard = argumentsMap[FIELD_PARAM_WIZARD] as Boolean?
                val securityExtraRootCheck =
                        argumentsMap[FIELD_PARAM_EXTRA_ROOT_CHECK_SECURITY] as Boolean?
                val securityExtraEmulatorCheck =
                        argumentsMap[FIELD_PARAM_EXTRA_EMULATOR_CHECK_SECURITY] as Boolean?
                val securityExtraSslPinning = argumentsMap[FIELD_PARAM_EXTRA_SSL_PINNING] as Boolean?
                val checkoutConfirmationScreen =
                        argumentsMap[FIELD_PARAM_SCREEN_CONFIRMATION_DEPARTURE] as Boolean?
                val returnType = argumentsMap[FIELD_PARAM_RETURN_TYPE] as String?
                val returnErrors = argumentsMap[FIELD_PARAM_RETURN_ERRORS] as Boolean?
                val checkBrightness = argumentsMap[FIELD_PARAM_CHECK_BRIGHTNESS] as Boolean?
                val checkEyes = argumentsMap[FIELD_PARAM_CHECK_EYES] as Boolean?
                val performance = argumentsMap[FIELD_PARAM_PERFORMANCE] as Boolean?
                val mudarCamera = argumentsMap[FIELD_PARAM_MUDAR_CAMERA] as Boolean?

                val textConfiguration = argumentsMap[FIELD_PARAM_TEXT_CONFIGURATION] as Map<*, *>?

                val intent = Intent(context, SelfieActivity::class.java)

                intent.putExtra(FIELD_PARAM_KEY, key)
                intent.putExtra(FIELD_PARAM_WIZARD, wizard)
                intent.putExtra(FIELD_PARAM_MUDAR_CAMERA, mudarCamera)                
                intent.putExtra(FIELD_PARAM_EXTRA_ROOT_CHECK_SECURITY, securityExtraRootCheck)
                intent.putExtra(FIELD_PARAM_EXTRA_EMULATOR_CHECK_SECURITY, securityExtraEmulatorCheck)
                intent.putExtra(FIELD_PARAM_EXTRA_SSL_PINNING, securityExtraSslPinning)
                intent.putExtra(FIELD_PARAM_SCREEN_CONFIRMATION_DEPARTURE, checkoutConfirmationScreen)
                intent.putExtra(FIELD_PARAM_RETURN_TYPE, returnType)
                intent.putExtra(FIELD_PARAM_RETURN_ERRORS, returnErrors)
                intent.putExtra(FIELD_PARAM_CHECK_BRIGHTNESS, checkBrightness)

                intent.putExtra(FIELD_PARAM_CHECK_EYES, checkEyes)
                intent.putExtra(FIELD_PARAM_PERFORMANCE, performance)

                intent.putExtra(FIELD_PARAM_TEXT_CONFIGURATION, mapToTextConfiguration(textConfiguration))

                callListenerInsideSDK()

                activity?.startActivityForResult(intent, REQUEST_CODE)
            }

            else -> {
                pendingResult?.notImplemented()
            }
        }
    }

    private fun callListenerInsideSDK() {
        SelfieActivity.callbackProcessamentoLiveness = CallbackProcessamentoLiveness {
            val response = HashMap<String, Any>()
            response.put(ID_KEY, it.get(
                    ID_KEY))
            response.put(CODE_KEY, it.get(
                    CODE_KEY))
            response.put(STATUS_KEY, it.get(
                    STATUS_KEY))
            response.put(CAPTURE_HOUR_KEY, it.get(
                    CAPTURE_HOUR_KEY))
            response.put(DESCRIPTION_KEY, it.get(
                    DESCRIPTION_KEY))
            response.put(TIME_KEY, it.get(
                    TIME_KEY))
            response.put(IMAGE_KEY, it.get(
                    IMAGE_KEY))
            pendingCallbackResult?.success(response)

        }
    }

    private fun mapToTextConfiguration(textConfigurationMap: Map<*, *>?): ConfiguracaoTexto {
        val textConfiguration = ConfiguracaoTexto()
        if (textConfigurationMap == null) return textConfiguration
        val fields: Array<Field> = textConfiguration.javaClass.fields
        for (field in fields) {
            try {
                val value: String? = textConfigurationMap[field.name] as String?
                field[textConfiguration] = value
            } catch (e: IllegalAccessException) {
                e.printStackTrace()
            }
        }
        return textConfiguration
    }

    @Synchronized
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode == REQUEST_CODE) {

            if (resultCode == Activity.RESULT_OK && data != null) {

                val selfie: Selfie? =
                        data.getSerializableExtra(FIELD_NAME_RESULT_SUCCESS_OBJECT) as Selfie?
                if (selfie != null) {
                    val parameter: MutableMap<String, Any> = java.util.HashMap()
                    parameter[FIELD_NAME_RESULT_ID] = selfie.id
                    parameter[FIELD_NAME_RESULT_IMAGE] = selfie.imagem

                    result?.success(parameter)
                }

                val error: Erro? =
                        data.getSerializableExtra(FIELD_NAME_RESULT_ERROR_OBJECT) as Erro?
                if (error != null) {
                    val parameter: MutableMap<String, Any> = java.util.HashMap()
                    parameter[FIELD_NAME_RESULT_ID] = error.id
                    parameter[FIELD_NAME_RESULT_ERROR_CODE] = error.codigo
                    parameter[FIELD_NAME_RESULT_ERROR_DESCRIPTION] = error.descricao

                    result?.success(parameter)
                }
            } else {
                val parameter: MutableMap<String, Any> = java.util.HashMap()
                parameter[FIELD_NAME_RESULT_ID] = ""
                parameter[FIELD_NAME_RESULT_ERROR_CODE] = "-1"
                parameter[FIELD_NAME_RESULT_ERROR_DESCRIPTION] = "Platform Error"
                result?.error("-1", "Platform Error", parameter)
            }
        }
        return false
    }

    @Synchronized
    override fun onAttachedToEngine(flutterPluginBinding: FlutterPluginBinding) {
        context = flutterPluginBinding.applicationContext
        channel = MethodChannel(flutterPluginBinding.binaryMessenger, CHANNEL_NAME)
        channel?.setMethodCallHandler(this)
    }

    @Synchronized
    override fun onDetachedFromEngine(binding: FlutterPluginBinding) {
        channel?.setMethodCallHandler(null)
        context = null
    }

    @Synchronized
    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        activity = binding.activity
        activityBinding = binding
        activityBinding?.addActivityResultListener(this)
    }

    @Synchronized
    override fun onDetachedFromActivityForConfigChanges() {
    }

    @Synchronized
    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        activity = binding.activity
    }

    @Synchronized
    override fun onDetachedFromActivity() {
        activity = null
        activityBinding?.removeActivityResultListener(this)
        activityBinding = null
    }

    companion object {
        private const val REQUEST_CODE = 1001
        private const val CHANNEL_NAME = "serasa.idf/selfie"
        private const val CALL_METHOD = "startCapture"

        private const val FIELD_PARAM_KEY = "chave"
        private const val FIELD_PARAM_WIZARD = "wizard"
        private const val FIELD_PARAM_MUDAR_CAMERA = "mudarCamera"
        private const val FIELD_PARAM_EXTRA_ROOT_CHECK_SECURITY = "segurancaExtraRootCheck"
        private const val FIELD_PARAM_EXTRA_EMULATOR_CHECK_SECURITY = "segurancaExtraEmulatorCheck"
        private const val FIELD_PARAM_EXTRA_SSL_PINNING = "segurancaExtraSslPinning"
        private const val FIELD_PARAM_SCREEN_CONFIRMATION_DEPARTURE = "telaConfirmacaoDeSaida"
        private const val FIELD_PARAM_RETURN_TYPE = "tipoRetorno"
        private const val FIELD_PARAM_RETURN_ERRORS = "retornarErros"
        private const val FIELD_PARAM_CHECK_BRIGHTNESS = "verificarLuminosidade"
        private const val FIELD_PARAM_CHECK_EYES = "verificarOlhos"
        private const val FIELD_PARAM_PERFORMANCE = "performance"
        private const val FIELD_PARAM_TEXT_CONFIGURATION = "configuracaoTexto"

        private const val FIELD_NAME_RESULT_SUCCESS_OBJECT = "selfie"
        private const val FIELD_NAME_RESULT_ERROR_OBJECT = "erro"
        private const val FIELD_NAME_RESULT_ID = "id"
        private const val FIELD_NAME_RESULT_IMAGE = "imagem"
        private const val FIELD_NAME_RESULT_ERROR_CODE = "codigo"
        private const val FIELD_NAME_RESULT_ERROR_DESCRIPTION = "descricao"

        private const val ID_KEY = "id";
        private const val CODE_KEY = "code";
        private const val STATUS_KEY = "status";
        private const val CAPTURE_HOUR_KEY = "captureHour";
        private const val DESCRIPTION_KEY = "description";
        private const val TIME_KEY = "time";
        private const val IMAGE_KEY = "image";
        private const val STATUS_SUCCESS_KEY = "sucesso";
        private const val STATUS_FAILURE_KEY = "falha";

        private const val DART_TO_SDK_EVENT_START_CAPTURE = "startCapture"
        private const val DART_TO_SDK_EVENT_DOCUMENT_CALLBACK_LISTENER = "callbackProcessamentoLiveness"

    }
}