import UIKit
import Flutter

enum ChannelName {
  static let capture = "serasa.idf/selfie"
  static let charging = "serasa.idf/capture"
}

@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
  private var eventSink: FlutterEventSink?

  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        GeneratedPluginRegistrant.register(with: self)
        
    guard let controller = window?.rootViewController as? FlutterViewController else {
      fatalError("rootViewController is not type FlutterViewController")
    }
        let navigationController = UINavigationController(rootViewController: controller)
        navigationController.isNavigationBarHidden = true
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
        
    let captureChannel = FlutterMethodChannel(name: ChannelName.capture,
                                              binaryMessenger: controller.binaryMessenger)
        captureChannel.setMethodCallHandler({(call: FlutterMethodCall, result: @escaping FlutterResult) -> Void in
//      guard call.method == "startCapture" else {
//        result(FlutterMethodNotImplemented)
//        return
//      }
            
            if call.method == "startCapture" {
                let arguments = call.arguments as! [String: Any]
            let capture = SelfieCaptureViewController(flutterResult: result, arguments: arguments)
            controller.navigationController?.pushViewController(capture, animated: true)
            }
            
 
            
    })
        
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
  
}
