import 'dart:async';
import 'package:flutter/material.dart';
import 'native_mode_serasa_idf_liveness_serasa.dart' as liveness_serasa;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color.fromARGB(255, 0, 45, 209)),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Demo Liveness Serasa Capture'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String _result = '';

  Future<void> _startCapture() async {
    var params = <String, Object>{};
    params[liveness_serasa.keyChave] = ""; // INSERT KEY HERE
    params[liveness_serasa.keyMudarCamera] = true;
    params[liveness_serasa.keyWizard] = true;
    params[liveness_serasa.keyVerificarLuminosidade] = false;
    params[liveness_serasa.keyRetornarErros] = false;
    params[liveness_serasa.keySegurancaExtraSslPinning] =
        true; // TO VALIDATE REQUESTS WITH SSL PINNING (BY DEFAULT IS FALSE)
    params[liveness_serasa.keySegurancaExtraRootCheck] =
        true; // TO CHECK IF DEVICE IS RUNNING IN ROOT MODE (BY DEFAULT IS FALSE)
    params[liveness_serasa.keySegurancaExtraEmulatorCheck] =
        true; // TO CHECK IF DEVICE IS A EMULATOR (BY DEFAULT IS FALSE)
    params[liveness_serasa.keyTelaConfirmacaoDeSaida] = true;
    params[liveness_serasa.keyVerificarOlhos] = true;
    params[liveness_serasa.keyPerformance] = true;
    params[liveness_serasa.keyTipoRetorno] = "base64";

    // Setting text configuration
    var configuracaoTextoParams = <String, String>{};

    configuracaoTextoParams["brscan_selfie_erro_selfie_captura"] = "Infelizmente tivemos um pequeno problema de conexão. Por favor, verifique sua internet e tente novamente.";
    configuracaoTextoParams["brscan_selfie_erro_ao_conectar_no_servidor"] = "Erro ao conectar com o servidor, verifique sua conexão e tente novamente.";
    configuracaoTextoParams["brscan_selfie_erro_ao_validar_chave"] = "Erro ao validar chave. Por favor, verifique e tente novamente.";
    configuracaoTextoParams["brscan_selfie_erro_baixa_luminosidade"] = "Procure um ambiente com boa iluminação e tente novamente.";
    configuracaoTextoParams["brscan_selfie_erro_device_rooted"] = "A aplicação não suporta dispositivos em modo root.";
    configuracaoTextoParams["brscan_selfie_erro_device_emulated"] = "A aplicação não suporta dispositivos emulados.";
    configuracaoTextoParams["brscan_selfie_erro_usuario_cancelou_acao"] = "Ação cancelada pelo usuário.";
    configuracaoTextoParams["brscan_selfie_erro_liberar_camera"] = "Para continuar é necessario liberar o acesso a câmera do dispositivo.";
    configuracaoTextoParams["brscan_selfie_erro_servidor"] = "Neste momento, não conseguimos carregar algumas informações.\nVocê pode tentar novamente mais tarde ou agora, se preferir.";
    configuracaoTextoParams["brscan_selfie_erro_processo"] = "Ocorreu uma falha ao concluir o processo. Por favor, tente novamente.";
    configuracaoTextoParams["brscan_selfie_erro_token_expired"] = "Por medidas de segurança, o tempo de sessão expirou, mas não se preocupe, você pode começar a confirmação novamente.";
    configuracaoTextoParams["brscan_selfie_erro_accelerometer"] = "Falha na inicialização do componente, o dispositivo não possui acelerômetro.";
    configuracaoTextoParams["brscan_selfie_erro_acesso_negado_title"] = "Acesso Negado";
    configuracaoTextoParams["brscan_selfie_erro_acesso_negado_subtitle"] = "Não podemos seguir enquanto não for liberado o acesso a câmera do dispositivo.";
    configuracaoTextoParams["brscan_selfie_erro_acesso_negado_botao_de_acao"] = "Como liberar câmera";
    configuracaoTextoParams["brscan_selfie_erro_captura_title"] = "Quase lá !";
    configuracaoTextoParams["brscan_selfie_erro_captura_subtitle"] = "Encontramos um problema ao concluir  processo, por favor, tente novamente.";
    configuracaoTextoParams["brscan_selfie_erro_captura_botao_tentar_novamente"] = "Tentar novamente";
    configuracaoTextoParams["brscan_selfie_erro_captura_botao_sair_do_processo"] = "Sair do processo";
    configuracaoTextoParams["brscan_selfie_posicione_o_aparelho_na_vertical"] = "Posicione o aparelho na vertical";
    configuracaoTextoParams["brscan_selfie_centralize_o_rosto"] = "Centralize o rosto";
    configuracaoTextoParams["brscan_selfie_aguarde_um_instante"] = "Aguarde nesta posição";
    configuracaoTextoParams["brscan_selfie_aguardando_o_rosto"] = "Aguardando o rosto";
    configuracaoTextoParams["brscan_selfie_fique_sozinho"] = "Fique sozinho";
    configuracaoTextoParams["brscan_selfie_alinhe_o_rosto"] = "Alinhe o rosto";
    configuracaoTextoParams["brscan_selfie_aproxime_o_aparelho"] = "Aproxime o aparelho";
    configuracaoTextoParams["brscan_selfie_afaste_o_aparelho"] = "Afaste o aparelho";
    configuracaoTextoParams["brscan_selfie_mantenha_os_olhos_abertos"] = "Mantenha os olhos abertos";
    configuracaoTextoParams["brscan_selfie_camera_frontal"] = "Câmera frontal";
    configuracaoTextoParams["brscan_selfie_camera_traseira"] = "Câmera traseira";
    configuracaoTextoParams["brscan_selfie_loading"] = "Aguarde um instante ...";
    configuracaoTextoParams["brscan_selfie_upload_image_subtitle_one"] = "Estamos carregando sua foto";
    configuracaoTextoParams["brscan_selfie_upload_image_subtitle_two"] = "Estamos preparando para fotografar";

    // Add text configuration
    params[liveness_serasa.keyConfiguracaoTexto] = configuracaoTextoParams;

    liveness_serasa.startCapture(
        params: params,
        onSuccess: (selfie) {
          // Callback Success

          debugPrint("--- Callback Success ---");
          debugPrint("id: ${selfie[liveness_serasa.keyResultId]}");
          debugPrint("imagem: ${selfie[liveness_serasa.keyResultImage]}");

          setState(() {
            _result = 'Success:\n ${selfie.toString()} ';
          });
        },
        onError: (error) {
          // Callback Error

          debugPrint("--- Callback Error ---");
          debugPrint("id: ${error[liveness_serasa.keyResultId]}");
          debugPrint("codigo: ${error[liveness_serasa.keyResultErrorCode]}");
          debugPrint(
              "descricao: ${error[liveness_serasa.keyResultErrorDescription]}");

          setState(() {
            _result = 'Error:\n ${error.toString()} ';
          });
        },
        onCallbackListener: (callbackListener) {
          // Callback callbackListener

          debugPrint("--- Selfie Processing callbackListener ---");

          debugPrint("image: ${callbackListener[liveness_serasa.keyImage]}");
          debugPrint("status: ${callbackListener[liveness_serasa.keyStatus]}");
          debugPrint("code: ${callbackListener[liveness_serasa.keyCode]}");
          debugPrint("id: ${callbackListener[liveness_serasa.keyResultId]}");
          debugPrint(
              "description: ${callbackListener[liveness_serasa.keyDescription]}");
          debugPrint("time: ${callbackListener[liveness_serasa.keyTime]}");
          debugPrint(
              "CaptureHour: ${callbackListener[liveness_serasa.keyCaptureHour]}");
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          foregroundColor: Colors.white,
          backgroundColor: const Color.fromARGB(255, 0, 45, 209),
          title: Text(widget.title),
        ),
        body: SingleChildScrollView(
            child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Visibility(
                  visible: _result.isNotEmpty,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      _result,
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                  )),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                    onPressed: _startCapture,
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: const Color.fromARGB(
                          255, 0, 45, 209), // Background color
                    ),
                    child: const Text("Start Selfie Capture")),
              ),
            ],
          ),
        )) // This trailing comma makes auto-formatting nicer for build methods.
        );
  }
}
