import { NativeModules, Platform } from 'react-native';

const LINKING_ERROR =
  `The package 'SerasaIdfCaptureSelfie' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ ios: "- You have run 'pod install'\n", default: '' }) +
  '- You rebuilt the app after installing the package\n' +
  '- You are not using Expo managed workflow\n';


const SerasaIdfCaptureSelfie = NativeModules.SerasaIdfCaptureSelfie
  ? NativeModules.SerasaIdfCaptureSelfie
  : new Proxy(
    {},
    {
      get() {
        throw new Error(LINKING_ERROR);
      },
    }
  );

  export type SelfieConfig = {
    chave: string,
    mudarCamera: boolean,
    wizard: boolean,
    segurancaExtraSslPinning: boolean,
    segurancaExtraRootCheck: boolean,
    verificarLuminosidade: boolean,
    verificarOlhos: boolean,
    performance: boolean,
    resolucao: 'low' | 'hd' | 'original',
    tipoRetorno: 'path' | 'base64',
    customizacaoTexto?: SelfieConfiguracaoTexto,
    retornarErros: boolean,
    acessibilidade: boolean,
    segurancaExtraEmulatorCheck: boolean,
    telaConfirmacaoDeSaida: boolean
  }

  export type Selfie = {
    imagem: string,
    id: string
  }
  
  
  export type ErroSelfie = {
    codigo: number,
    descricao: string,
    id: string
  }
  
  export type SelfieConfiguracaoTexto = {
    brscan_selfie_erro_selfie_captura?: string;
    brscan_selfie_erro_ao_conectar_no_servidor?: string;
    brscan_selfie_erro_ao_validar_chave?: string;
    brscan_selfie_erro_baixa_luminosidade?: string;  
    brscan_selfie_erro_device_rooted?: string;
    brscan_selfie_erro_usuario_cancelou_acao?: string;  
    brscan_selfie_erro_liberar_camera?: string;
    brscan_selfie_erro_servidor?: string;
    brscan_selfie_erro_processo?: string;
    brscan_selfie_erro_token_expired?: string;
    brscan_selfie_erro_accelerometer?: string;  
    brscan_selfie_erro_acesso_negado_title?: string;
    brscan_selfie_erro_acesso_negado_subtitle?: string;
    brscan_selfie_erro_acesso_negado_botao_de_acao?: string;  
    brscan_selfie_erro_captura_title?: string;
    brscan_selfie_erro_captura_subtitle?: string;
    brscan_selfie_erro_captura_botao_tentar_novamente?: string;
    brscan_selfie_erro_captura_botao_sair_do_processo?: string;  
    brscan_selfie_posicione_o_aparelho_na_vertical?: string;
    brscan_selfie_centralize_o_rosto?: string;
    brscan_selfie_aguarde_um_instante?: string;
    brscan_selfie_aguardando_o_rosto?: string;
    brscan_selfie_fique_sozinho?: string;
    brscan_selfie_alinhe_o_rosto?: string;
    brscan_selfie_aproxime_o_aparelho?: string;
    brscan_selfie_afaste_o_aparelho?: string;
    brscan_selfie_mantenha_os_olhos_abertos?: string;  
    brscan_selfie_camera_frontal?: string;
    brscan_selfie_camera_traseira?: string;  
    brscan_selfie_loading?: string;
    brscan_selfie_erro_device_emulated?: string;
  }

export const startSelfie = (config: SelfieConfig, sucesso: (resultado: Selfie) => void, falha: (resultado: ErroSelfie) => void) => {
  const { chave, mudarCamera, wizard, segurancaExtraSslPinning, segurancaExtraRootCheck, verificarLuminosidade, verificarOlhos, performance, resolucao, 
    tipoRetorno, customizacaoTexto, retornarErros, acessibilidade, segurancaExtraEmulatorCheck, telaConfirmacaoDeSaida } = config;
  SerasaIdfCaptureSelfie.captureSelfie(chave, mudarCamera, wizard, segurancaExtraSslPinning, segurancaExtraRootCheck, verificarLuminosidade, verificarOlhos, 
    performance, resolucao, tipoRetorno, customizacaoTexto, retornarErros, acessibilidade, segurancaExtraEmulatorCheck, telaConfirmacaoDeSaida, sucesso, falha)
}

export type ListenerResult = {
  status:string,
  code: number,
  description: string,
  id: string,
  time: number,
  type: string,
  captureHour: string,
  image: string
}



export const callbackProcessamentoLivenessSerasa = (callbackListener: (resultado: ListenerResult) => void) => {
  const result = (resultado: ListenerResult) => {
    callbackListener(resultado)
    callbackProcessamentoLivenessSerasa(callbackListener)
  }
  SerasaIdfCaptureSelfie.callbackProcessamentoLivenessSerasa(result)
}