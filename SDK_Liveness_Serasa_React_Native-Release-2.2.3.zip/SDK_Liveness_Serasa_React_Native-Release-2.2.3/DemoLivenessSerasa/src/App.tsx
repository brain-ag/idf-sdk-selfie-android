import * as React from 'react';

import { StyleSheet, View, TouchableOpacity, Text } from 'react-native';
import { ErroSelfie, ListenerResult, Selfie, SelfieConfig, callbackProcessamentoLivenessSerasa, startSelfie } from './native_module_selfie';

export default function App() {

    const [resultSuccessSelfie, setResultSuccessSelfie] = React.useState<Selfie | null>(null);
    const [resultErrorSelfie, setResultErrorSelfie] = React.useState<ErroSelfie | null>(null);

    // Selfie

    const selfieConfig: SelfieConfig = {
        chave: '',// INSERT KEY HERE
        mudarCamera: false,
        wizard: true,
        segurancaExtraRootCheck: true,// TO CHECK IF DEVICE IS RUNNING IN ROOT MODE (BY DEFAULT IS FALSE)
        segurancaExtraSslPinning: true,// TO VALIDATE REQUESTS WITH SSL PINNING (BY DEFAULT IS FALSE)
        segurancaExtraEmulatorCheck: true,// TO CHECK IF DEVICE IS A EMULATOR (BY DEFAULT IS FALSE)
        verificarLuminosidade: false,
        verificarOlhos: false,
        performance: false,
        resolucao: 'low',
        tipoRetorno: 'path',
        retornarErros: false,
        acessibilidade: false,
        telaConfirmacaoDeSaida: false
    }

    const handleSelfieSuccess = (selfie: Selfie) => {
        const json = JSON.stringify(selfie, null, 2)
        console.log(json)
        setResultSuccessSelfie(selfie)
        setResultErrorSelfie(null)
    }

    const handleSelfieErro = (erroSelfie: ErroSelfie) => {
        const json = JSON.stringify(erroSelfie, null, 2);
        console.log(json)
        setResultErrorSelfie(erroSelfie)
        setResultSuccessSelfie(null)
    }

    const callbackListener = (result: ListenerResult) => {
        const json = JSON.stringify(result, null, 2)
        console.log(json)
    }

    const handleSelfieStart = () => {
        callbackProcessamentoLivenessSerasa(callbackListener);
        startSelfie(selfieConfig, handleSelfieSuccess, handleSelfieErro)
    }

    return (
        <View style={styles.container}>


            <TouchableOpacity onPress={handleSelfieStart} style={styles.button}>
                <Text style={styles.buttonTitle}>Captura de Selfie</Text>
            </TouchableOpacity>


            {
                resultSuccessSelfie && <Text style={styles.resultText}>
                    id:  {resultSuccessSelfie.id + "\n\n"}
                    selfie:  {resultSuccessSelfie.imagem.substring(0, 200) + "...\n\n"}
                </Text>

            }


            {
                resultErrorSelfie && <Text style={styles.resultText}>
                    id:  {resultErrorSelfie.id + "\n\n"}
                    codigo:  {resultErrorSelfie.codigo + "\n\n"}
                    descricao:  {resultErrorSelfie.descricao + "\n\n"}
                </Text>

            }



        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-evenly',
        backgroundColor: "#f5f5f5"
    },
    box: {
        width: 60,
        height: 60,
        marginVertical: 20,
    },
    button: {
        width: "80%",
        height: 56,
        backgroundColor: "#002DD1",
        borderRadius: 56,
        alignItems: 'center',
        justifyContent: 'center'
    },
    buttonTitle: {
        color: "#f5f5f5",
        fontSize: 16
    },
    resultText: {
        color: "#333",
        fontSize: 16,
        padding: 16
    }
});
