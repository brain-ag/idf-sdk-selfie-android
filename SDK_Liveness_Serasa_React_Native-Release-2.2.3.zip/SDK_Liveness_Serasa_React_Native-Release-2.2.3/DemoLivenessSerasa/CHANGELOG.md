## [2.2.3] - 24-04-2024
- Melhoria: Inclusão de biblioteca liveness 2.2.3 IOS.
- Melhoria: Inclusão de biblioteca liveness 2.2.3 Android.

## [2.2.2] - 24-04-2024
- Melhoria: Inclusão de biblioteca liveness 2.2.2 IOS.
- Melhoria: Inclusão de biblioteca liveness 2.2.1 Android.

## [2.2.0] - 30-05-2023
- Melhoria: Inclusão de biblioteca liveness 2.2.0.

## [2.0.0] - 18-04-2023
- Melhoria: Inclusão do módulo liveness.
- Melhoria: Inclusão de biblioteca liveness 2.1.0.
